/** @jsxImportSource @emotion/react */
import { css } from '@emotion/react';
import React, { useState, useEffect } from 'react';
import ContactList from './ContactList';
import AddContact from './AddContact';
import SearchBar from './SearchBar';
import AOS from 'aos';
import 'aos/dist/aos.css';

const pageStyles = css`
  background-image: url('/wave.svg'); // Ubah sesuai nama dan jalur gambar SVG Anda
  background-size: cover;
  background-repeat: no-repeat;
  min-height: 100vh; // Untuk memastikan tinggi minimal setara dengan tinggi viewport
`;

// Warna Biru Muda untuk Navbar
const navbarStyles = css`
  background-color: #fff;
  padding: 10px;
  text-align: left;
`;

const phoneBookStyles = css`
  max-width: 70%; /* Lebar konten maksimum */
  margin: 0 auto;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 10px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  margin-top: 5%;
  background-color: #fff;

  h1 {
    font-size: 24px;
    margin-bottom: 20px;
    color: #333; /* Warna teks hitam */
  }
`;

const logoStyles = css`
  font-size: 24px;
  color: navy;
  margin-right: 20px; /* Memberikan jarak antara logo dan konten lainnya */
  font-family: 'Poppins', sans-serif;
`;

interface Contact {
  id: number;
  name: string;
  phoneNumber: string;
  favorite: boolean;
}

const PhoneBook: React.FC = () => {
  useEffect(() => {
    AOS.init();
    AOS.refresh();
  }, []); // useEffect akan dijalankan sekali setelah komponen di-mount

  const [contacts, setContacts] = useState<Contact[]>([]);
  const [newContact, setNewContact] = useState<Contact>({
    id: 0,
    name: '',
    phoneNumber: '',
    favorite: false,
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setNewContact({
      ...newContact,
      [e.target.name]: e.target.value,
    });
  };

  const addContact = () => {
    setContacts([...contacts, newContact]);
    setNewContact({
      id: 0,
      name: '',
      phoneNumber: '',
      favorite: false,
    });
  };

  const deleteContact = (id: number) => {
    const updatedContacts = contacts.filter((contact) => contact.id !== id);
    setContacts(updatedContacts);
  };

  const toggleFavorite = (id: number) => {
    const updatedContacts = contacts.map((contact) => {
      if (contact.id === id) {
        return {
          ...contact,
          favorite: !contact.favorite,
        };
      }
      return contact;
    });
    setContacts(updatedContacts);
  };

  const searchContact = (searchTerm: string) => {

  };

  return (
    <div css={pageStyles}  data-aos="fade-up" data-aos-duration="2000">
      <div css={navbarStyles} data-aos="fade-down" data-aos-duration="2000">
        <h1 css={logoStyles}>Phonebook Reza</h1>
      </div>
      
      {/* Content */}
      <div css={phoneBookStyles} data-aos="fade-up" data-aos-duration="2000">
        <h1 data-aos="fade-right" data-aos-duration="2000">Phone Book</h1>
        {/* AddContact Component */}
        <AddContact
          newContact={newContact}
          handleInputChange={handleInputChange}
          addContact={addContact}
          data-aos="fade-left"
          data-aos-duration="2000"
        />
        {/* SearchBar Component */}
        <SearchBar searchContact={searchContact} data-aos="fade-right" data-aos-duration="2000"/>
        {/* ContactList Component */}
        <ContactList
          contacts={contacts}
          toggleFavorite={toggleFavorite}
          deleteContact={deleteContact}
          data-aos="fade-up"
          data-aos-duration="2000"
        />
      </div>
    </div>
  );
};

export default PhoneBook;
