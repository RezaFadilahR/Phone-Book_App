/** @jsxImportSource @emotion/react */
import { css } from '@emotion/react';
import React, { useState } from 'react';
import { useMutation } from '@apollo/client';
import gql from 'graphql-tag';

interface Contact {
  id: number;
  name: string;
  phoneNumber: string;
  favorite: boolean;
}

interface AddContactProps {
  newContact: Contact;
  handleInputChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  addContact: () => void; // Tambahkan prop addContact di sini
}

const addContactStyles = css`
  background-color: #f9f9f9;
  border: 1px solid #ccc;
  border-radius: 5px;
  padding: 20px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  text-align: center;

  h2 {
    font-size: 24px;
    margin-bottom: 20px;
    color: #333;
  }

  input {
    width: calc(100% - 60px); /* Menggunakan calc untuk menghitung lebar dengan mengurangkan 60px (30px kiri + 30px kanan) */
    padding: 10px 30px; /* Menambahkan padding 10px di atas/bawah dan 30px di kiri/kanan */
    margin-bottom: 15px;
    border: 1px solid #ccc;
    border-radius: 3px;
  }

  button {
    background-color: #0077cc;
    color: #fff;
    border: none;
    padding: 10px 20px;
    border-radius: 3px;
    cursor: pointer;
    font-size: 16px;

    &:hover {
      background-color: #005599;
    }
  }
`;

const ADD_CONTACT = gql`
  mutation AddContact($name: String!, $phoneNumber: String!) {
    addContact(name: $name, phoneNumber: $phoneNumber) {
      id
      name
      phoneNumber
      favorite
    }
  }
`;

const AddContact: React.FC<AddContactProps> = ({ newContact, handleInputChange, addContact }) => {
  const [addContactMutation] = useMutation(ADD_CONTACT);

  const addNewContact = () => {
    addContactMutation({
      variables: {
        name: newContact.name,
        phoneNumber: newContact.phoneNumber,
      },
    })
      .then((result) => {
        // Handle successful addition of the contact if needed
        addContact(); // Panggil addContact setelah berhasil menambahkan kontak
      })
      .catch((error) => {
        // Handle errors if there are any
      });
  };

  return (
    <div css={addContactStyles}>
      <h2>Add New Contact</h2>
      <input
        type="text"
        name="name"
        placeholder="Name"
        value={newContact.name}
        onChange={handleInputChange}
      />
      <input
        type="text"
        name="phoneNumber"
        placeholder="Phone Number"
        value={newContact.phoneNumber}
        onChange={handleInputChange}
      />
      <button onClick={addNewContact}>Add Contact</button> {/* Menggunakan addNewContact yang telah diubah namanya */}
    </div>
  );
};

export default AddContact;
