/** @jsxImportSource @emotion/react */
import { css } from '@emotion/react';
import React from 'react';

interface SearchBarProps {
  searchContact: (searchTerm: string) => void;
}

const searchBarStyles = css`
  width: calc(100% - 60px); /* Menggunakan calc untuk menghitung lebar dengan mengurangkan 60px (30px kiri + 30px kanan) */
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
  font-size: 16px;
  margin-top: 30px;
  padding-right: 42px;

  &::placeholder {
    color: #999;
  }
`;



const SearchBar: React.FC<SearchBarProps> = ({ searchContact }) => {
  return (
    <input
      type="text"
      placeholder="Search Contact"
      onChange={(e) => searchContact(e.target.value)}
      css={searchBarStyles}
    />
  );
};

export default SearchBar;
