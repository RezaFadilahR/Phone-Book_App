// setupProxy.ts

import { createProxyMiddleware } from 'http-proxy-middleware';
import { Express } from 'express';

const setupProxy = (app: Express) => {
  app.use(
    '/graphql',  // Change this to match your GraphQL endpoint
    createProxyMiddleware({
      target: 'https://web-tools.tokopedia.com',
      changeOrigin: true,
      secure: false, // Do not verify SSL certificates
    })
  );
};

export default setupProxy;
