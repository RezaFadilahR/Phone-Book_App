/** @jsxImportSource @emotion/react */
import { css } from '@emotion/react';
import React from 'react';
import { useQuery } from '@apollo/client'; // Impor useQuery dari Apollo Client
import gql from 'graphql-tag'; // Impor gql untuk mendefinisikan query

// Definisikan query GraphQL
const GET_CONTACTS = gql`
  query GetContacts {
    contacts {
      id
      name
      phoneNumber
      favorite
    }
  }
`;

interface Contact {
  id: number;
  name: string;
  phoneNumber: string;
  favorite: boolean;
}

interface ContactListProps {
  contacts: Contact[];
  toggleFavorite: (id: number) => void;
  deleteContact: (id: number) => void;
}


const tableStyles = css`
  width: 70%;
  border-collapse: collapse;
  margin: 0 auto; /* Menyusun tabel di tengah halaman */

  th, td {
    border: 1px solid #ccc;
    padding: 8px;
    text-align: left;
  }

  th {
    background-color: #0077cc;
    color: #fff;
  }

  tr:nth-of-type(2n) {
    background-color: #f0f0f0;
  }

  tr:nth-of-type(2n+1) {
    background-color: #fff;
  }

  button {
    background-color: #0077cc;
    color: #fff;
    border: none;
    padding: 5px 10px;
    border-radius: 3px;
    cursor: pointer;

    &:hover {
      background-color: #005599;
    }
  }

  caption {
    font-size: 24px;
    text-align: center;
    margin-bottom: 30px;
    margin-top: 30px;
  }
`;

const ContactList: React.FC<ContactListProps> = ({ toggleFavorite, deleteContact }) => {
  // Menggunakan useQuery untuk menjalankan query GraphQL
  const { loading, error, data } = useQuery(GET_CONTACTS);

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error.message}</p>;

  const contacts = data.contacts as Contact[];

  return (
    <table css={tableStyles}>
      <caption>Contact List</caption>
      <thead>
        <tr>
          <th>Name</th>
          <th>Phone Number</th>
          <th>Favorite</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        {contacts.map((contact) => (
          <tr key={contact.id}>
            <td>{contact.name}</td>
            <td>{contact.phoneNumber}</td>
            <td>{contact.favorite ? 'Yes' : 'No'}</td>
            <td>
              <button onClick={() => toggleFavorite(contact.id)}>
                {contact.favorite ? 'Remove Favorite' : 'Add Favorite'}
              </button>
              <button onClick={() => deleteContact(contact.id)}>Delete</button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default ContactList;
